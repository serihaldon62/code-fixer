=== QUANTUM FOREX TRADING SYSTEM - DEPLOYMENT GUIDE ===

This package contains everything needed to install the Continuous Learning System on a new Windows Server.

=== 1. INSTALL PYTHON ===
Download and install Python 3.10+ (Check "Add Python to PATH" during install).
Open cmd and verify:
> python --version

=== 2. SETUP ENVIRONMENT ===
1. Create a folder (e.g., C:\QuantumTrading) and copy ALL these files there.
2. Open cmd in that folder.
3. Install dependencies:
   > pip install -r requirements.txt

=== 3. CONFIGURE MT4 ===
1. Copy 'QuantumFileClient.mq4' to your MT4 Data Folder -> MQL4/Experts.
2. Open MT4, drag the EA to a EURUSD H1 chart.
3. IMPORTANT: Set EA Input 'LookbackCandles' to 50.
4. IMPORTANT: Set EA Input 'StopLoss' to 500 (which means 50.0 pips). THIS IS CRITICAL FOR SAFETY.

=== 4. START THE SYSTEM ===
Option A (Manual):
Double-click 'auto_start.bat'.

Option B (Automatic on Reboot):
1. Press Win+R, type 'shell:startup', press Enter.
2. Right-click inside that folder -> New -> Shortcut.
3. Browse to 'C:\QuantumTrading\auto_start.bat'.
4. Next -> Finish.

Now the system will restart automatically if the server reboots!

=== HOW IT WORKS ===
- 'live_trainer.py' runs every hour, downloads new data, trains 'model.pkl'.
- 'file_bridge.py' watches MT4 requests, loads 'model.pkl' (hot-reload), and predicts.
- Learning is saved to disk continuously.

Good Luck! 🚀
