import argparse
import numpy as np
import os
import time
import pandas as pd
from data_loader import ForexDataLoader
from quantum_model import QuantumModel

def main():
    parser = argparse.ArgumentParser(description='Live Quantum Forex Trainer')
    parser.add_argument('--symbol', type=str, default='EURUSD=X', help='Forex Symbol')
    parser.add_argument('--epochs', type=int, default=20, help='Epochs per update round (default: 20)')
    parser.add_argument('--interval', type=int, default=3600, help='Seconds between updates (default: 3600/1h)')
    parser.add_argument('--save_path', type=str, default='model.pkl', help='Path to save model')

    args = parser.parse_args()

    print(f"=== QUANTUM LIVE TRAINER STARTED ===")
    print(f"Symbol: {args.symbol}")
    print(f"Update Interval: {args.interval} seconds")
    print(f"Target Model: {args.save_path}")
    
    # Initialize Model Structure
    q_model = QuantumModel(num_qubits=4, num_features=4, maxiter=args.epochs)
    
    # Warma Start if exists
    if os.path.exists(args.save_path):
        try:
            q_model.load(args.save_path)
            print(">> Loaded existing model. Continuing training...")
        except:
            pass

    while True:
        try:
           print(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] Fetching fresh data...")
           
           # 1. FETCH FRESH DATA (INSIDE LOOP) to learn new patterns
           # Using '2y' to match the robust backtest logic
           loader = ForexDataLoader(symbol=args.symbol, interval='1h', period='2y')
           X_raw, y_raw = loader.prepare_features(lookback=4)
           
           # Use all available data
           X_train = X_raw
           y_train = y_raw
           # FIX: Select LAST 4 features (T-0) to match Bridge logic
           # Previous version [:4] took T-3 (Oldest), which was a mismatch.
           X_train_reduced = X_train[:, -4:]
           
           print(f"Data updated. Samples: {len(X_train)}")
           
           # 2. TRAIN
           print(f"Training for {args.epochs} epochs...")
           q_model.train(X_train_reduced, y_train)
           
           # 3. SAVE (Triggers Hot-Reload in Bridge)
           q_model.save(args.save_path)
           print(f">> Model updated and saved to {args.save_path}")
           
        except Exception as e:
            print(f"CRITICAL ERROR in training loop: {e}")
        
        # 4. SLEEP
        print(f"Sleeping for {args.interval} seconds...")
        time.sleep(args.interval)

if __name__ == "__main__":
    main()
