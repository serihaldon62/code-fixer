import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit_machine_learning.neural_networks import EstimatorQNN
from qiskit_machine_learning.algorithms.classifiers import NeuralNetworkClassifier
from qiskit.quantum_info import SparsePauliOp
from qiskit_algorithms.optimizers import COBYLA
from qiskit.circuit.library import ZZFeatureMap, RealAmplitudes

# Using Qiskit for broader compatibility and ease of use in this demo context
# (Qulacs can be integrated if strictly required, but Qiskit is safer for cross-platform Python-only envs without compilation)

class QuantumModel:
    def __init__(self, num_qubits=4, num_features=8, maxiter=100):
        self.num_qubits = num_qubits
        self.num_features = num_features
        self.feature_map = self._create_feature_map(num_qubits, num_features)
        self.ansatz = self._create_ansatz(num_qubits)
        self.qc = QuantumCircuit(num_qubits)
        self.qc.compose(self.feature_map, inplace=True)
        self.qc.compose(self.ansatz, inplace=True)
        
        # Observable: Z measurement on the first qubit
        obs_string = "I" * (num_qubits - 1) + "Z"
        observable = SparsePauliOp.from_list([(obs_string, 1)])

        self.qnn = EstimatorQNN(
            circuit=self.qc,
            input_params=self.feature_map.parameters,
            weight_params=self.ansatz.parameters,
            observables=observable
        )
        
        self.iteration = 0
        self.classifier = NeuralNetworkClassifier(
            self.qnn, 
            optimizer=COBYLA(maxiter=maxiter),
            loss='squared_error',
            callback=self._callback_graph,
            warm_start=True # Essential for continuous training!
        )

    def _create_feature_map(self, num_qubits, num_features):
        # Use standard ZZFeatureMap for better entanglement and data encoding
        # reps=1 is usually enough for simple patterns, reps=2 for complex
        return ZZFeatureMap(feature_dimension=num_qubits, reps=1, entanglement='linear')

    def _create_ansatz(self, num_qubits):
        # Use RealAmplitudes (hardware efficient)
        return RealAmplitudes(num_qubits=num_qubits, reps=2, entanglement='linear')

    def _callback_graph(self, weights, obj_func_eval):
        self.iteration += 1
        self.loss_history.append(obj_func_eval)
        print(f"Iteration {self.iteration} - Loss: {obj_func_eval:.4f}")

    def train(self, X, y):
        print("Training Quantum Model...")
        self.iteration = 0 # Reset iteration count for new training session
        self.loss_history = [] # Clear loss history for new training session
        # Map 0/1 to -1/+1 for convergence if needed, but Classifier handles labels
        self.classifier.fit(X, y)
        print("Training Complete.")

    def predict(self, X):
        return self.classifier.predict(X)
        
    def predict_proba(self, X):
        return self.classifier.predict_proba(X)
        
    def save(self, file_path):
        import pickle
        with open(file_path, 'wb') as f:
            pickle.dump(self.classifier, f)
        print(f"Model saved to {file_path}")

    def load(self, file_path):
        import pickle
        with open(file_path, 'rb') as f:
            self.classifier = pickle.load(f)
        print(f"Model loaded from {file_path}")
