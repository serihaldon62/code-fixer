import time
import os
import json
import numpy as np
import pandas as pd
from quantum_model import QuantumModel
from sklearn.preprocessing import MinMaxScaler

# ------------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------------
# We will ask the user for this path interactively or via a config file.
# For simplicity, we default to a local 'test_files' folder, but user must override.
FILES_PATH = "" 

REQUIRED_FILES = ["quantum_request.txt"]
RESPONSE_FILE = "quantum_response.txt"

# Model Globals
q_model = None
last_model_time = 0

def load_quantum_model():
    global q_model, last_model_time
    model_path = 'model.pkl'
    
    if os.path.exists(model_path):
        try:
            file_mtime = os.path.getmtime(model_path)
            if file_mtime > last_model_time:
                print(f"Loading/Reloading Model (ts: {file_mtime})...")
                # Re-instantiate to clear state
                q_model = QuantumModel(num_qubits=4, num_features=4, maxiter=1)
                q_model.load(model_path)
                last_model_time = file_mtime
                print("Model loaded successfully.")
                return True
        except Exception as e:
            print(f"Error loading model: {e}")
            return False
    else:
        print("Waiting for model.pkl to be created by trainer...")
        return False
    
    return True # Model already loaded and current

def process_request(file_path):
    global q_model
    
    print(f"Processing request from {file_path}...")
    
    try:
        # 1. Read Data
        # Retry logic for reading (in case MT4 is still writing)
        content = ""
        for i in range(5):
            try:
                with open(file_path, 'r') as f:
                    content = f.read()
                if len(content) > 5:
                    break
            except:
                time.sleep(0.1)
        
        if not content:
            print("Empty request file.")
            return

        data = json.loads(content)
        closes = data.get('closes', [])
        
        if len(closes) < 30:
            print("Not enough data in request.")
            return
            
        # 2. Prepare Features (Same logic as app.py)
        df = pd.DataFrame({'Close': closes})
        df['Returns'] = df['Close'].pct_change()
        
        # RSI
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))
        
        # MACD
        exp12 = df['Close'].ewm(span=12, adjust=False).mean()
        exp26 = df['Close'].ewm(span=26, adjust=False).mean()
        df['MACD'] = exp12 - exp26
        
        df.dropna(inplace=True)
        
        # Scale
        # Re-fit scaler dynamically (as in app.py)
        feature_cols = ['Close', 'Returns', 'RSI', 'MACD']
        data_values = df[feature_cols].values
        
        scaler = MinMaxScaler(feature_range=(0, 2 * np.pi))
        scaled_data = scaler.fit_transform(data_values)
        
        # FIX: The model was trained on SINGLE TIME STEP (4 features), not a flattened window (16 features).
        # We need to take just the LAST row of data.
        last_row = scaled_data[-1] 
        # Check if we need to slice it if scaler produced more columns?
        # Scaler was fit on 4 cols, so last_row is len 4.
        
        X_input = np.array([last_row])
        
        # 3. Predict
        if q_model is None:
            print("Model not loaded!")
            return

        print("Calculating Prediction...")
        probs = q_model.predict_proba(X_input)[0]
        print(f"Raw Probs: {probs}")
        
        # Handle case where model only returns 1 probability (rare edge case in sklearn/qiskit)
        # FIX: The raw output seems to be an Expectation Value (range -1 to 1) from the Z-operator,
        # rather than a probability (0 to 1). This happens with EstimatorQNN sometimes dependent on setup.
        
        raw_val = probs[0]
        
        # Logic for Expectation Value (-1 = Down, +1 = Up)
        # We can map it to probability for display: (val + 1) / 2
        p_up = (raw_val + 1) / 2
        p_down = 1.0 - p_up
        
        signal = 0
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

        # Thresholds (using the converted probability)
        # DYNAMIC MODE: Send all signals > 50%
        # The MT4 Client will adjust Lot Size based on the 'confidence' value.
        if p_up > 0.50:
            signal = 1
        elif p_down > 0.50:
            signal = -1
        else:
            signal = 0
            
        print(f"Prediction: Signal={signal}, Raw={raw_val:.4f}, Prob_Up={p_up:.2f}")
        
        # 4. Write Response
        resp_data = {
            "signal": signal,
            "confidence": float(max(p_up, p_down))
        }
        
        resp_path = os.path.join(FILES_PATH, RESPONSE_FILE)
        
        with open(resp_path, 'w') as f:
            json.dump(resp_data, f)
            
        print(f"Response written to {resp_path}")
        
        # 5. Clean up Request
        try:
            os.remove(file_path)
            print("Request processed and deleted.")
        except:
            pass # Maybe MT4 locked it?
            
    except Exception as e:
        print(f"Error processing request: {e}")

def main():
    global FILES_PATH
    
    print("-------------------------------------------------")
    print("      Quantum Forex FILE BRIDGE                  ")
    print("-------------------------------------------------")
    print("This bridge reads data files from MT4, predicts,")
    print("and writes the result back.")
    print("NETWORK FREE MODE.")
    print("-------------------------------------------------")
    
    # Check for config
    config_file = "bridge_config.txt"
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            FILES_PATH = f.read().strip()
            print(f"Loaded MT4 Files Path from config: {FILES_PATH}")
    
    if not FILES_PATH or not os.path.exists(FILES_PATH):
        print("\nIMPORTANT: Please enter the full path to your MT4 Files folder.")
        print("Example: C:\\Users\\You\\AppData\\Roaming\\MetaQuotes\\Terminal\\...\\MQL4\\Files")
        print("(You can find this in MT4 -> File -> Open Data Folder -> MQL4 -> Files)")
        FILES_PATH = input("Path: ").strip().replace('"', '')
        
        # Save for next time
        with open(config_file, 'w') as f:
            f.write(FILES_PATH)
            
    print(f"\nMonitoring {FILES_PATH} for requests...")
    
    while True:
        # Reload model if needed
        load_quantum_model()
        
        req_path = os.path.join(FILES_PATH, "quantum_request.txt")
        
        if os.path.exists(req_path):
            process_request(req_path)
            
        time.sleep(0.5) # Poll every 500ms

if __name__ == "__main__":
    main()
