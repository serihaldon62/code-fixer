import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

class ForexDataLoader:
    def __init__(self, symbol='EURUSD=X', interval='1h', period='1mo'):
        self.symbol = symbol
        self.interval = interval
        self.period = period
        self.data = None
        # Scale to [0, 2*pi] for rotation encoding, or [0, 1] generally
        self.scaler = MinMaxScaler(feature_range=(0, 1))

    def fetch_data(self):
        filename = f"{self.symbol}_{self.period}_{self.interval}.csv"
        try:
            print(f"Fetching data for {self.symbol}...")
            self.data = yf.download(self.symbol, interval=self.interval, period=self.period)
            
            if self.data.empty:
                raise ValueError("Empty data downloaded")
                
            # Ensure we just have the price data
            if isinstance(self.data.columns, pd.MultiIndex):
                self.data = self.data.xs(self.symbol, level=1, axis=1)
            
            self.data.dropna(inplace=True)
            self.data.to_csv(filename)
            print(f"Fetched {len(self.data)} data points and saved to {filename}.")
            
        except Exception as e:
            print(f"Download failed: {e}. Trying to load local cache: {filename}")
            try:
                self.data = pd.read_csv(filename, index_col=0, parse_dates=True)
                print(f"Loaded {len(self.data)} data points from cache.")
            except FileNotFoundError:
                raise ValueError(f"No local data found for {filename} and download failed.")
        
        return self.data

    def prepare_features(self, lookback=4):
        """
        Prepares data for quantum circuit.
        Returns X (features) and y (target: 1 if up, 0 if down).
        """
        if self.data is None:
            self.fetch_data()
            
        df = self.data.copy()
        
        # Simple Technical Indicators
        df['Returns'] = df['Close'].pct_change()
        
        # RSI
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['RSI'] = 100 - (100 / (1 + rs))
        
        # MACD
        exp12 = df['Close'].ewm(span=12, adjust=False).mean()
        exp26 = df['Close'].ewm(span=26, adjust=False).mean()
        df['MACD'] = exp12 - exp26
        
        df.dropna(inplace=True)
        
        # Target: 1 if Next Close > Current Close (Price Up), else 0
        df['Target'] = np.where(df['Close'].shift(-1) > df['Close'], 1, 0)
        
        # Drop the last row as it has no target
        df = df.iloc[:-1]

        # Select features to embed
        # Using sophisticated features now
        feature_cols = ['Close', 'Returns', 'RSI', 'MACD']
        
        # Scale features to [0, 2*pi] for full rotation encoding
        data_values = df[feature_cols].values
        self.scaler = MinMaxScaler(feature_range=(0, 2 * np.pi))
        scaled_data = self.scaler.fit_transform(data_values)
        
        X, y = [], []
        # Create sequences
        for i in range(len(scaled_data) - lookback):
            # Flatten the sequence for the quantum circuit input
            # e.g. lookback 4 * 3 features = 12 inputs
            seq = scaled_data[i:i+lookback].flatten() 
            X.append(seq)
            y.append(df['Target'].iloc[i+lookback])
            
        return np.array(X), np.array(y)

if __name__ == "__main__":
    loader = ForexDataLoader()
    X, y = loader.prepare_features()
    print(f"Features shape: {X.shape}, Target shape: {y.shape}")
    print(f"Sample X: {X[0]}")
    print(f"Sample y: {y[0]}")
